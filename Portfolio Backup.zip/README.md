# Alex V. Nunez Portfolio
In this web portfolio, you will find information about me my education, and my path as an Electronics Engineer, and as a Software Developer. 
As well as, some projects that I have developed.

Created by:
* Alex V. Nunez

Links:
* GITHUB:
  https://anunez1990.github.io/Portfolio/
* PROJECT  MOCKUP
 https://github.com/Anunez1990/Portfolio/blob/master/pictures/anunez1990-github-io-Portfolio.pdf
